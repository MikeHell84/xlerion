<?php
namespace Tests\Feature;

use Tests\TestCase;
use Illuminate\Foundation\Testing\RefreshDatabase;

class CloseAuctionsTest extends TestCase
{
    use RefreshDatabase;

    public function test_close_command_runs()
    {
        // Placeholder: implement when factories are added.
        $this->assertTrue(true);
    }
}
